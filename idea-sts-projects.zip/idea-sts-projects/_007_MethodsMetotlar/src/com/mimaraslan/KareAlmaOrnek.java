package com.mimaraslan;

public class KareAlmaOrnek {

	
	
	public static void main(String[] args) {

		System.out.println(kareAl(8));
		
		System.out.println(Math.pow(8, 2));
		
	}

	private static int kareAl(int sayi) {
		return sayi*sayi;
	}

	

	



	



}
