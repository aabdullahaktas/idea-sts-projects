package com.mimaraslan;

public class Kasiyer extends Kisi {

    private double maas;

    public Kasiyer(int id, String isim, double maas) {
        super(id, isim);
        this.maas = maas;
    }
}
