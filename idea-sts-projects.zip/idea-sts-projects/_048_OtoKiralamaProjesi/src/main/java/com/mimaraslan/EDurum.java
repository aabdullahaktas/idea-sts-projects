package com.mimaraslan;

public enum EDurum {

    KIRADA, GALERIDE

}
