package com.mimaraslan;

public class Kopek extends Hayvan{

    @Override
    public void ses(){
        System.out.println("Hav hav");
    }
}
