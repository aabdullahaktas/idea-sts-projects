package com.mimaraslan;

public class Hayvan {

    public void ses(){
        System.out.println("Hayvan sınıfı ses");
    }

    public String selamYaz (String adi){
        return "SELAM " + adi;
    }
}
