package com.mimaraslan;

public class Kedi extends Hayvan{

    @Override
    public void ses(){
        System.out.println("Miyav miyav");
    }
}
