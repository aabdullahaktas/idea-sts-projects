package com.mimaraslan;

public class Kus extends Hayvan{

    @Override
    public void ses(){
        System.out.println("Cik cik");
    }
}
