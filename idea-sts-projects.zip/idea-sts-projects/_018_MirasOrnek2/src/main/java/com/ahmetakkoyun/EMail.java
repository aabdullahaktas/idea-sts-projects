package com.ahmetakkoyun;

public class EMail extends Document {

    private String subject;
    private String[] to;

    public String getSubject() {
        return subject;
    }

    public String[] getTo() {
        return to;
    }

}
