package com.ahmetakkoyun;

public class Book extends Document {
    private String title;

    public String getTitle() {
        return title;
    }
}
