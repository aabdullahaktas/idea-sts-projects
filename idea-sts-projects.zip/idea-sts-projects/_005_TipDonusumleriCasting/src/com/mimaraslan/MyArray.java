package com.mimaraslan;

public class MyArray {

	public static void main(String[] args) {


		String adi1 = "Ali";
		String adi2 = "Veli";
		String adi3 = "Ahmet";
		String adi4 = "Mehmet";
						// 0      1       2         3
		String adi [] = {"Ali", "Veli", "Ahmet", "Mehmet"};
		System.out.println(adi[0]);
		System.out.println(adi[1]);
		System.out.println(adi[2]);
		System.out.println(adi[3]);
		
		
	}

}
