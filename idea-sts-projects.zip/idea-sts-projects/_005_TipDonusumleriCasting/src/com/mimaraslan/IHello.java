package com.mimaraslan;

public interface IHello {

	public void selamVer();
	
	public void kural2();
	
	public void kural3(String mesaj);
	
}
