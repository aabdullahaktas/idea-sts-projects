package com.mimaraslan;

public interface IDeneme {

	public void adiniziYaz();
}
