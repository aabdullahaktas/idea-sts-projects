package com.mimaraslan.service;

public class PersonelService {
}
