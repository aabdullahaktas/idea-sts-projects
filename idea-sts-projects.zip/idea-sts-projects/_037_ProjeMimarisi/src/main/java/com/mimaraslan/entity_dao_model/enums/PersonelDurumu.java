package com.mimaraslan.entity_dao_model.enums;

public enum PersonelDurumu {
    AKTIF,
    PASIF,
    DONDURMUS
}
