package com.mimaraslan.repository;

public class PersonelRepository {
}
