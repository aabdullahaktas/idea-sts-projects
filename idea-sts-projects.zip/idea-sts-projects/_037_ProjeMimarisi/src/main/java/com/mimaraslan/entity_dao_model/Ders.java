package com.mimaraslan.entity_dao_model;

public class Ders {
}
