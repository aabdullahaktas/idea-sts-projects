package com.mimaraslan.repository;

import com.mimaraslan.entity_dao_model.Ders;

import java.util.ArrayList;
import java.util.List;

public class DersRepository {


}
