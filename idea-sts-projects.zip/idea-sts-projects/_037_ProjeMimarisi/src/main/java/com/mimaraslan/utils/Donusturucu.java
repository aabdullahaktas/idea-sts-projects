package com.mimaraslan.utils;

public class Donusturucu {
}
