package com.mimaraslan.utils;

public class Hesaplama {
}
