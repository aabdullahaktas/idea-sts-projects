package org.example;

public class Zebra {
    private Boolean is_wild;

    public Boolean getIs_wild() {
        return is_wild;
    }

    public void setIs_wild(Boolean is_wild) {
        this.is_wild = is_wild;
    }
    public void run(){
        System.out.println("run metodu");
    }
}
