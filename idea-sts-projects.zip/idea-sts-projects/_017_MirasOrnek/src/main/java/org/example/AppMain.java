package org.example;

public class AppMain {
    public static void main(String[] args) {
        Duck duck1 = new Duck();
        duck1.setBeakColor("kırmızı");
        System.out.println(duck1.getBeakColor());
    }
}
