package com.mimaraslan.ders1;

public class AppMain {

    public static void main(String[] args) {
        int personelYasi = 10;

        final double PI_SAYISI = 3.14;

        System.out.println(PI_SAYISI);

        String str1 = new String();
/*
        Integer sayi1 ;
        sayi1 = 2000000000000;
        System.out.println(sayi1.MAX_VALUE);
*/
         //   0 1 2 3 4 5 6 7 8 9 A B C D E F


        int sayi1 = 0b101; // 2 lik taban
        int sayi2 = 3;     // 10 luk taban
        int sayi3 = 0x3F;  // 16 lık taban
        System.out.println(sayi1 + sayi2 + sayi3);





    }
}
