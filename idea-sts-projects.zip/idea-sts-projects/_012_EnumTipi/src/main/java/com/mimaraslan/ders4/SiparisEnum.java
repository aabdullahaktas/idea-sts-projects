package com.mimaraslan.ders4;

public class SiparisEnum {

    enum Boyut {
        KUCUK,

        ORTA,

        BUYUK,

        EKSTRA_BUYUK
    }

}
