package com.mimaraslan._05_hiyerasi_kurma.cokdosyada;

public class Timezone {
    private String offset;
    private String description;
}
