package com.mimaraslan._05_hiyerasi_kurma.cokdosyada;

public class Name {

    private String title;
    private String first;
    private String last;

}
