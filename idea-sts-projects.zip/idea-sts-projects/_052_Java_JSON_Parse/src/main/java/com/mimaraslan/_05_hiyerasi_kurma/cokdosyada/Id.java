package com.mimaraslan._05_hiyerasi_kurma.cokdosyada;

public class Id {

    private String name;
    private String value;
}
