package com.mimaraslan._05_hiyerasi_kurma.cokdosyada;

public class Coordinates {
    private String latitude;
    private String longitude;
}
