package com.mimaraslan._05_hiyerasi_kurma.cokdosyada;

public class Picture {
    private String large;
    private String medium;
    private String thumbnail;

}
