package com.mimaraslan._05_hiyerasi_kurma.cokdosyada;

public class Login {
    private String uuid;
    private String username;
    private String password;
    private String salt;
    private String md5;
    private String sha1;
    private String sha256;
}
