package com.mimaraslan._05_hiyerasi_kurma.cokdosyada;

public class Location {

    private String city;
    private String state;
    private String country;
    private int postcode;

    private Street street;
    private Coordinates coordinates;
    private Timezone timezone;

}
