package com.mimaraslan._05_hiyerasi_kurma.cokdosyada;

public class Dob {

    private String date;
    private String age;
}
