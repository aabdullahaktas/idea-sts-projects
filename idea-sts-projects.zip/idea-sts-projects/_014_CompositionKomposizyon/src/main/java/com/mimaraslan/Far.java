package com.mimaraslan;

public class Far {
    public Far() {
        System.out.println("Far");
    }
}
