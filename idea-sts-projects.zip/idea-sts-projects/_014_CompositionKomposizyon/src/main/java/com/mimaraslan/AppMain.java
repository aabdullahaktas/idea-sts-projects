package com.mimaraslan;

public class AppMain {

    public static void main(String[] args) {
        System.out.println("Ana merkez sınıf");

        Araba araba = new Araba();
       // Yakit yakit = new Yakit();

        araba.hareketeGec();
    }
}
