package com.mimaraslan;

public class Yakit {

    public Yakit() {
        System.out.println("Yakıt");
    }

    public void depo() {
        System.out.println("Depoda yakıt var.");
    }
}
