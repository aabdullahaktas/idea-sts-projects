package com.mimaraslan;

public class Ayna {

    public Ayna() {
        System.out.println("Ayna");
    }
}
