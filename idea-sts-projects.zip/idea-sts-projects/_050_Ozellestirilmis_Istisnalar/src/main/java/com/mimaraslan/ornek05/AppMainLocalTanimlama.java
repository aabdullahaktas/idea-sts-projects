package com.mimaraslan.ornek05;

import java.util.List;

public class AppMainLocalTanimlama {

    public static void main(String[] args) {

         String ifade; // = "Selam"
         String [] gunler; // = {"Pa","Sa","Ca","Pe","Cu","Ct","Pz"}
         List<String> ogrencilerListesi; // = null; ogrencilerListesi.add("Gani");
/*
        System.out.println(ifade);
        System.out.println(gunler);
        System.out.println(ogrencilerListesi);
*/
    }
}
