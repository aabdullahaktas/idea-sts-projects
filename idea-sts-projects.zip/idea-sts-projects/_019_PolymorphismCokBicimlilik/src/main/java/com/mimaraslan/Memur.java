package com.mimaraslan;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Memur extends Personel{
    private short kidemYili;
}
