package com.mimaraslan;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Mudur extends Memur{
    private String aileYadimi;
}
