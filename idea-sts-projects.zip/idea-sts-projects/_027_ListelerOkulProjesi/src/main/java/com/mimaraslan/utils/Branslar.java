package com.mimaraslan.utils;

public enum Branslar {
    SinifOgretmeni,
    Matematik,
    Turkce,
    Tarih,
    Cografya,
    Ingilizce,
    BedenEgitimi
}
