package com.mimaraslan.utils;

public enum Dersler {
    Geometri,
    Matematik,
    Turkce,
    Tarih,
    Cografya,
    Ingilizce,
    BedenEgitimi
}
