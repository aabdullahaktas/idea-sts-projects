package com.mimaraslan;

public class AppMain {
    public static void main(String[] args) {
        Cocuk cocuk = new Cocuk();
       cocuk.konustuguDil();
    }
}
