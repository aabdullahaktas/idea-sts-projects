package com.mimaraslan;

public class Cocuk extends Anne {
/*
    @Override
    protected void konustuguDil (){
        System.out.println("Türkçe");
    }
    */
}
