package com.mimaraslan;

public class AppMain {
    public static void main(String[] args) {


        SinirlandirilmisTipOrnek <Double, String> obj = new SinirlandirilmisTipOrnek(100);
        obj.yazdir();

    }
}

