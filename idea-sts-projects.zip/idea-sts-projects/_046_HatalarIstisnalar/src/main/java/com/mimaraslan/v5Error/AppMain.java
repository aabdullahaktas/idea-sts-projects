package com.mimaraslan.v5Error;

public class AppMain {
    public static void main(String[] args) {

        int myArr[] = new int[10];

        // myArr[25] = 100;

        // myArr[25]   100;

        // System.out.println("SONUC " + myARR);

        int a = 10;
        int b = 60;
        int toplam = a + b;
   //     System.out.println("Sonuç : " + toplam;

/*
        while (true){

        }
        System.out.println("Selam");
*/
    }
}
