package org.turkeyjug;

public class  Motorsiklet extends Tasit{

    public Motorsiklet() {
        super();
        // KODLAR superden sonra
    }

    public Motorsiklet(int tekerSayisi) {
        super(tekerSayisi);
        // KODLAR superden sonra
    }
}
