package org.turkeyjug;

public class Bisiklet extends Tasit{
/*
    public Bisiklet() {
        super();
    }
    */

    public Bisiklet(int tekerSayisi) {
        super(tekerSayisi);
    }

}
