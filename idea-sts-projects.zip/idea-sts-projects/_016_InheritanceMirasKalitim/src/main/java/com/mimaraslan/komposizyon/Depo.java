package com.mimaraslan.komposizyon;

public class Depo {
}
