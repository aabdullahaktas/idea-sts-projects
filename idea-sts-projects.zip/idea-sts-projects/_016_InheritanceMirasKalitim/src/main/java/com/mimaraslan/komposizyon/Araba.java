package com.mimaraslan.komposizyon;

public class Araba {

    Cam cam = new Cam();
    Depo depo = new Depo();
    Teker teker = new Teker();

   // Far far = new Far();

    public static void main(String[] args) {

    }
}
