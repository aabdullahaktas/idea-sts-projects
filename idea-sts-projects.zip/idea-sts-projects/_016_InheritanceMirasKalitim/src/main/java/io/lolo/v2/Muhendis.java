package io.lolo.v2;

public class Muhendis  extends Personel{

    private String temelBeceri;
    private String calismaSekli;

    public String getTemelBeceri() {
        return temelBeceri;
    }

    public void setTemelBeceri(String temelBeceri) {
        this.temelBeceri = temelBeceri;
    }

    public String getCalismaSekli() {
        return calismaSekli;
    }

    public void setCalismaSekli(String calismaSekli) {
        this.calismaSekli = calismaSekli;
    }

}
