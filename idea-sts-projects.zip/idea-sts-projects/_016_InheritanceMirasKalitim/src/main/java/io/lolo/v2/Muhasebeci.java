package io.lolo.v2;

public class Muhasebeci  extends Personel{

    private String muhasebeciUnvani;


    public String getMuhasebeciUnvani() {
        return muhasebeciUnvani;
    }

    public void setMuhasebeciUnvani(String muhasebeciUnvani) {
        this.muhasebeciUnvani = muhasebeciUnvani;
    }

}
