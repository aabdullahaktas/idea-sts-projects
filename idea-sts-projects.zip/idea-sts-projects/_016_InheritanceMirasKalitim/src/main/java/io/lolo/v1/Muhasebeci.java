package io.lolo.v1;

public class Muhasebeci  extends Personel {

    private String muhasebeciUnvani;

    private long gorevTazminati;



    public String getMuhasebeciUnvani() {
        return muhasebeciUnvani;
    }

    public void setMuhasebeciUnvani(String muhasebeciUnvani) {
        this.muhasebeciUnvani = muhasebeciUnvani;
    }

    public long getGorevTazminati() {
        return gorevTazminati;
    }

    public void setGorevTazminati(long gorevTazminati) {
        this.gorevTazminati = gorevTazminati;
    }
}
