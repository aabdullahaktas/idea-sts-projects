package com.mimaraslan;

public class Kopek  {

    void yemekYe(){
        System.out.println("Kopek sınıfındaki yemek yeme normal metodu. EZME");
    }


    public void sesVer() {
        System.out.println("Hav hav  - abstract metod");
    }


    public void hareketEt() {

    }


    public void bilgisiniGetir() {


    }
}
