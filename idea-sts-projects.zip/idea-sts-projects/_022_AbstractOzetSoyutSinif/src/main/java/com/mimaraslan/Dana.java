package com.mimaraslan;

public class Dana extends Hayvan{
    @Override
    public void sesVer() {

    }

    @Override
    public void hareketEt() {

    }

    @Override
    public void bilgisiniGetir() {

    }
}
