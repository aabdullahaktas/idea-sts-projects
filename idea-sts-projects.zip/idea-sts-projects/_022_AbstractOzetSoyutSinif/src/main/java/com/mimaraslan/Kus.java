package com.mimaraslan;

public class Kus extends Hayvan{
    @Override
    public void sesVer() {

    }

    @Override
    public void hareketEt() {

    }

    @Override
    public void bilgisiniGetir() {

    }
}
