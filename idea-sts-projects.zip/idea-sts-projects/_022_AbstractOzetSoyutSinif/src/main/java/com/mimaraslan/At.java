package com.mimaraslan;

public class At extends Hayvan{


    @Override
    public void sesVer() {
        System.out.println("Deh deh");
    }

    @Override
    public void hareketEt() {

    }

    @Override
    public void bilgisiniGetir() {

    }
}
