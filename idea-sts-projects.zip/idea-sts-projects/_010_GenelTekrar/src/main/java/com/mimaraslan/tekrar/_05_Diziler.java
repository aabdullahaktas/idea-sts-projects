package com.mimaraslan.tekrar;

public class _05_Diziler {

    public static void main(String[] args) {
        int a0;
        int a1;
        int a2;
        int a3;
        int a4;

        int a[] = new int [5];
       // a[0]  a[1]  a[2]  a[3]

        a[0] = 7;
        a[1] = 34;
        a[2] = 9;
        a[3] = 12;

        System.out.println(a[0] + " " + a[1]  + " " +  a[2]  + " " +  a[3]);

        int b[] = {7, 34, 9, 12};
        // b[0]  b[1]  b[2]  b[3]
        System.out.println(b[0] + " " + b[1]  + " " +  b[2]  + " " +  b[3]);

    }
}
