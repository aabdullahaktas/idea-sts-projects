package com.mimaraslan.ornekler;

public class ForToplama {
    public static void main(String[] args) {

        int sayac = 0;
        for (int i = 1; i <= 10; i++) {
            //sayac  =  sayac + i;
              sayac +=  i;
        }

        System.out.println(sayac);
    }
}
