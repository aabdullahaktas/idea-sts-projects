package com.mimaraslan.tekrar;
public class _00_Main {
    public static void main(String[] args) {

        /*
        * 1-  Değişkenler
        * 2 - Operatörler
        * 3 - Döngüler
        * 4 - Karar Yapıları
        * 5 - Diziler
        * */




    }
}