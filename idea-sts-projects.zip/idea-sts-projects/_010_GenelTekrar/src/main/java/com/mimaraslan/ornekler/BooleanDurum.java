package com.mimaraslan.ornekler;

public class BooleanDurum {
    public static void main(String[] args) {
        int s1 = 10;
        int s2 = 4;

        System.out.println( s1 > s2); //true
        System.out.println( s1 >= s2); //true
        System.out.println( s1 < s2); //false


    }
}
