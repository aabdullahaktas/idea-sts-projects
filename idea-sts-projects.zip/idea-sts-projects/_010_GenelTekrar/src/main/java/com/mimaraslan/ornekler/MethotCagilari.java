package com.mimaraslan.ornekler;

public class MethotCagilari {

    public static void main(String[] args) {
        kulaklik();
    }

    private static void kulaklik() {
        System.out.println("KULAKLIK");
        sagKulaklik();
        solKulaklik();

    }

    private static void solKulaklik() {
        System.out.println("solKulaklik");
    }

    private static void sagKulaklik() {
        System.out.println("sagKulaklik");
    }


}
