package com.mimaraslan.tekrar;

public class _01_Degiskenler {

    public static void main(String[] args) {

        byte myByteVal = 1;
        short myShortVal = 1;
        int myIntVal = 1;
        long myLongVal = 1111111111;
        float myFloatVal = 1.123456F;

        double myDoubleVal = 1.12345678901234567890;
        System.out.println(myDoubleVal);

        char myCharVal = 'A';
        System.out.println(myCharVal);
        myCharVal = 108;
        System.out.println(myCharVal);

        String ifade = "Bu bir mesajdır.";

        boolean myBooleanVal = true; // false;


        // new sözcüğü
        Byte myByteVal2 = 1;
        Short myShortVal2 = 1;
        Integer myIntVal2 = 1;
        Long myLongVal2 = 1111111111L;
        Float myFloatVal2 = 1.123456F;
        Double myDoubleVal2 = 1.12345678901234567890;
        Character myCharVal2 = 'A';
        Boolean myBooleanVal2 = true; // false;
        String myStringVal2 = "Selam";

    }

}
