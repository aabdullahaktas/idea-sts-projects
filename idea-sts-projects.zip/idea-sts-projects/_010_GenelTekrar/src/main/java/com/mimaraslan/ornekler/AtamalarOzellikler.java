package com.mimaraslan.ornekler;

public class AtamalarOzellikler {

    public static void main(String[] args) {
        double a = 10.0_0_0_0_0_0;

        char myChar = 'A';

        byte myByte = 127;



    }
}
