package com.mimaraslan.tekrar;

public class _03_KararYapilari {
    public static void main(String[] args) {

        if (true) {
            System.out.println("Koşul doğru");
        }


        boolean durum = 10 > 4;
        if (durum) {
            System.out.println("ŞART DOĞRU");
        } else {
            System.out.println("ŞART DOĞRU DEĞİL");
        }


        int s1 = 10;
        int s2 = 1;
        int s3 = 5;

        if ((s1 > s2) && (s3 < s1)) {

        } else if (s1 > s2 * 3) {

        } else {
        }

    }
}
