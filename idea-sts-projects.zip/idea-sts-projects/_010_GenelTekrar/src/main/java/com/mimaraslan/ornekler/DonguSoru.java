package com.mimaraslan.ornekler;

public class DonguSoru {

    public static void main(String[] args) {

        // 10 ile 30 arasındaki sayilari 30'da dahil ekrana yazdır.

        for (int i = 10; i <= 30 ; i++) {
            System.out.println(i);
        }
    }
}
