package com.mimaraslan.model.factory.v1pojo;

public enum TasimaTipi {
	KARA,
	HAVA,
	DENIZ
}
