package com.mimaraslan.model.factory.v2pojo;

public class Text implements IDocument {

    public String getDocumentType() {
        return "TEXT";
    }
}
