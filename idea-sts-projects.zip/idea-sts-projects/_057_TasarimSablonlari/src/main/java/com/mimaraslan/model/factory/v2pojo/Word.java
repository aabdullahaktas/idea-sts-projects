package com.mimaraslan.model.factory.v2pojo;

public class Word implements IDocument {

	public String getDocumentType() {
		return "WORD";
	}
}
