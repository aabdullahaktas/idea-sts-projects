package com.mimaraslan.model.factory.v2pojo;

public class Pdf implements IDocument {

	public String getDocumentType() {
		return "PDF";
	}
}
