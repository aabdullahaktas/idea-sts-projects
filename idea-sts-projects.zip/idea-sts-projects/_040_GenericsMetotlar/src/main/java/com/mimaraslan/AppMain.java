package com.mimaraslan;

public class AppMain {
    public static void main(String[] args) {

      JenerikMetot obj = new JenerikMetot();

      obj.ekrandaYaz(10, "Balıkesir");
      obj.ekrandaYaz("27", "Gaziantep");
      obj.ekrandaYaz('3', "Afyon");

    }
}