package com.mimaraslan.lambda04;

public interface Bolme {
    int getBolmeYap(int a, int b);
}
