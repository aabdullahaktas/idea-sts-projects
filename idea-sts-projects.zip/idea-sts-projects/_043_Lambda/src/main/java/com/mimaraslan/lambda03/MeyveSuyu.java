package com.mimaraslan.lambda03;

public interface MeyveSuyu {
    public String getAroma(String meyveAdi);
}
