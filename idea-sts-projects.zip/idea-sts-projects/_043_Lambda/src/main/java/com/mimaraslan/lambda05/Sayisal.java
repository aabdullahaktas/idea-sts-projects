package com.mimaraslan.lambda05;

public interface Sayisal {

    boolean sayiKontrol(int a, int b);

}
