package com.mimaraslan.lambda01;

public interface Sekil{
    public void dikdortgen();
}