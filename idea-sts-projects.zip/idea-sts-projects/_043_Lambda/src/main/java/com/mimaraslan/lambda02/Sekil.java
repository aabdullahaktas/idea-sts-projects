package com.mimaraslan.lambda02;

public interface Sekil {
    public String dikdortgen();
}