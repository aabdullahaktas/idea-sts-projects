package com.mimaraslan.solidprensibleri.rapor;

import com.mimaraslan.solidprensibleri.Musteri;

public interface IJson {

    public abstract  void musteriRaporJson(Musteri musteri);
}
