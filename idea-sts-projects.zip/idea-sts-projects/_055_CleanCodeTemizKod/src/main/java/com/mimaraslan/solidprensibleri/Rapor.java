package com.mimaraslan.solidprensibleri;

public abstract class Rapor {

    public abstract  void mustreriRaporBilginiNotEt(Musteri musteri);


/*
    public abstract  void mustreriRaporExcel(Musteri musteri);

    public abstract void musteriRaporPdf(Musteri musteri) ;

    public abstract  void musteriRaporJson(Musteri musteri);
    */
}
