package com.mimaraslan.solidprensibleri.rapor;

import com.mimaraslan.solidprensibleri.Musteri;

public interface IExcel {

    public void mustreriRaporExcel(Musteri musteri);


}
