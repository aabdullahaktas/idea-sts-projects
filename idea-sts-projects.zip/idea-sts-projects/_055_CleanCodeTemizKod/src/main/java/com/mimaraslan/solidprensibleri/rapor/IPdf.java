package com.mimaraslan.solidprensibleri.rapor;

import com.mimaraslan.solidprensibleri.Musteri;

public interface IPdf {

    public abstract void musteriRaporPdf(Musteri musteri) ;

}
