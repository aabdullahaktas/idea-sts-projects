Otobüslerin personel (soförleri) var.
Otobüslerin kimisi 56 koltuk - 46 koltuk.

Otobüslerin bakımı var.
Bakımı yapan ustalar var.

Otobüslerde bagaj taşınıyor.
Babajların da ebatları var. (Zarf) --- Kırılabilir, Kırılmaz.

Araba otomobil 4 tane de arabası varmış.

Motor da var 2 tane.
-------------------------------------------------

Arac
Otobüs (koltuk 46-54) - Araba - Motor

Personel
Yonetici - Tamirci - OfisCalisani - Kurye - Sofor

Kargo
Bagaj - (Zarf, kutu, canta)


