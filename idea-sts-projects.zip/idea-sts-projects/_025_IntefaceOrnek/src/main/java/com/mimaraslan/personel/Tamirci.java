package com.mimaraslan.personel;

public class Tamirci extends Personel{
}
