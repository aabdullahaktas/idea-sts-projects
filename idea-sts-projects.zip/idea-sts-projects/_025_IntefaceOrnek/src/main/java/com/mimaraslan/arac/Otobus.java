package com.mimaraslan.arac;


public class Otobus extends Arac implements Mesafe {


    @Override
    public String getYurtDisiIzni() {
        return "Yurtdışı izni var.";
    }
}


