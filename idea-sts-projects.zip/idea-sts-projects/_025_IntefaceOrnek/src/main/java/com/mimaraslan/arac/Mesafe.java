package com.mimaraslan.arac;

public interface Mesafe {

    String getYurtDisiIzni();
}
