package com.mimaraslan.arac;

public class Motor extends Arac{
}
