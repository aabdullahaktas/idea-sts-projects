package com.mimaraslan.arac;

public class Araba extends Arac {
}
