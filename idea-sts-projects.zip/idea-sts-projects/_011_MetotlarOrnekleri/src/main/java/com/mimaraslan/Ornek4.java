package com.mimaraslan;

public class Ornek4 {

    public Ornek4() {
        System.out.println("Nesne oluşturuldu.");
    }

    public static void main(String[] args) {

        Ornek4 obj1 = new Ornek4();
        Ornek4 obj2 = new Ornek4();

        System.out.println(obj1);
        System.out.println(obj2);

        String str1 = new String("Veli");
        System.out.println(str1);

    }

}
