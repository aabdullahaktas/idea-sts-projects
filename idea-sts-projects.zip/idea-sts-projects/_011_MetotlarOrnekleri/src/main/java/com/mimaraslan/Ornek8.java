package com.mimaraslan;

public class Ornek8 {
    public static void main(String [] args ) {
        System.out.println("Selam");

        System.out.println(args[0]);
        System.out.println(args[1]);
        System.out.println(args[2]);
        System.out.println(args[3]);
        System.out.println(args[4]);


    }
}
