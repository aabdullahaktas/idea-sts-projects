package com.mimaraslan;

public class Ornek6 {
    int a, b, c, d, e ;
    float g, h ,k, o, z;
    String r, m, l, p;

    int [] myArr1;
    char [] myArr2;
    Integer [] myArr3;

    public Ornek6(int a, int d, float h, String p) {
        this.a = a;
        this.d = d;
        this.h = h;
        this.p = p;
    }

    public Ornek6(int a, int b, int c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }

    public Ornek6(int a, String r, String m) {
        this.a = a;
        this.r = r;
        this.m = m;
    }

    public Ornek6(float h, float z, String m, int[] myArr1, char[] myArr2, Integer[] myArr3) {
        this.h = h;
        this.z = z;
        this.m = m;
        this.myArr1 = myArr1;
        this.myArr2 = myArr2;
        this.myArr3 = myArr3;
    }

    public Ornek6() {

    }

    public static void main(String[] args) {
        Ornek6 obj = new Ornek6();

        String str1 = new String();

    }

}
