package com.mimaraslan;

public interface Arayuz {


    void konumaGit();

}
