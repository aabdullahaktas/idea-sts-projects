package com.mimaraslan;

public class SomutSinif {

    void hareketEt(){

    }
}
