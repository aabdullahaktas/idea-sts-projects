package com.mimaraslan;

public class AltSinif1 extends SomutSinif {
}
