package com.mimaraslan;

public class AltSinif3 implements Arayuz{
    @Override
    public void konumaGit() {

    }
}
