package com.mimaraslan;

public class AltSinif2 extends SoyutSinif {

    @Override
    void selamVer() {

    }
}
