package com.mimaraslan;

public abstract class SoyutSinif {

   abstract void selamVer();
}
