package merhaba;

// TEK SATIRLIK ACIKLAMA

/*
 * Bu
 * çok
 * satırlı
 * bir 
 * aciklamadir
 * 
 * */

/*
 Bu çok satirli 
 aciklama 2
 */
public class MerhabaJava {

	// TODO ben cozume bu algoritma ile gittim.
	public static void main(String[] args) {

		/*
		 * 2 sayiyi toplama kodunu yazalim.
		 * 
		 * 1. Adim: Birinci sayiyi al. 
		 * 2. Adim: ikinci sayiyi al. 
		 * 3. Adim: Birinci sayi ile ikinci sayiyi topla 
		 * 4. Adim: Sonucu yazdir
		 */

		int sayi1 = 3;
		int sayi2 = 24;
		int sonuc = sayi1 + sayi2;

		System.out.println(sonuc);
		System.out.println("Bu toplamanın sonucu: " + sonuc);		
	}
}
