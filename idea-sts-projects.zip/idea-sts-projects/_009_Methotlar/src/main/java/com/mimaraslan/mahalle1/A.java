package com.mimaraslan.mahalle1;
public class A {
    public void goster() {
        System.out.println("Ben A sınıfındaki public göster metoduyum.");
    }
}