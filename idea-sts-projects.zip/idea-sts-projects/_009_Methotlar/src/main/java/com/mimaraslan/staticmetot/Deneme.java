package com.mimaraslan.staticmetot;

public class Deneme {
    public static void main(String[] args) {

/*   static ise SINIFIN_ADI.METOT_ADI

       MyApp.ekranaSelamYaz();
       MyApp.ekranaSelamYaz("Orhun");
       MyApp.ekranaSelamYaz("Orhun", "Bayındır");
*/


        MyApp obj = new MyApp();
        obj.ekranaSelamYaz();
        obj.ekranaSelamYaz("Orhun");
        obj.ekranaSelamYaz("Orhun", "Bayındır");
    }
}
