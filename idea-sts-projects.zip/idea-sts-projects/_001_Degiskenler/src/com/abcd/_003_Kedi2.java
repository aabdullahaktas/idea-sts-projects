package com.abcd;

public class _003_Kedi2 {

	public static void main(String[] args) {

		int yasi = 0;
		String cinsi = null;
		String adi = null;
		String renk = null;

		System.out.println("YAŞI  : " + yasi);
		System.out.println("CİNSİ : " + cinsi);
		System.out.println("ADI   : " + adi);
		System.out.println("RENK  : " + renk);

		System.out.println("------------------------");	
		
		yasi = 3;
		cinsi = "Ankara Kedisi";
		adi = "Pamuk";
		renk = "Alacalı";

		System.out.println("YAŞI  : " + yasi + " -  CİNSİ : " + cinsi);
		System.out.println("ADI   : " + adi  + " - RENK  : " + renk);

		System.out.println("------------------------");

		yasi = 4;
		cinsi = "Van Kedisi";
		adi = "Milan";
		renk = "Beyaz";
		
		System.out.println("YAŞI  : " + yasi);
		System.out.println("CİNSİ : " + cinsi);
		System.out.println("ADI   : " + adi);
		System.out.println("RENK  : " + renk);

		
		}

}
