/**
 * Lisans bilgileri
 */
package com.abcd;

/**
 * @author Mimar Aslan
 * @since 2023
 * @version 1.0.0
 */
public class _001_MyApp {

	/*
	 * // HAZIRLAYICI - YAPICI public MyApp() { 
	 * // TODO yapilacak işlerin notudur. }
	 */
	public static void main(String[] args) {

		System.out.println("Merhaba Java");

		// String YAZILAR ICIN
		System.out.println("Merhaba " + "Java");
		System.out.println("Merhaba" + " " + "Java");
		System.out.println("args DEĞERİ : " + args);
		System.out.println("null DEĞERİ : " + null);

		//System.err.println("MESAJ GOSTER");

		System.out.println(1 + 3);
		System.out.println('A' + 'B');
		System.out.println('A' + "B");
		
	}

}
