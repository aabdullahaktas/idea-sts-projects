package com.abcd;

public class _002_Kedi {

	public static void main(String[] args) {

		int yasi = 4;
		String cinsi = "Van Kedisi";
		String adi = "Milan";
		String renk = "Beyaz";

		System.out.println("YAŞI  : " + yasi);
		System.out.println("CİNSİ : " + cinsi);
		System.out.println("ADI   : " + adi);
		System.out.println("RENK  : " + renk);

		System.out.println("------------------------");
		
		yasi = 3;
		cinsi = "Ankara Kedisi";
		adi = "Pamuk";
		renk = "Alacalı";

		System.out.println("YAŞI  : " + yasi + " -  CİNSİ : " + cinsi);
		System.out.println("ADI   : " + adi  + " - RENK  : " + renk);
	}

}
