package com.mimaraslan.models;

public class Kitap {
}
