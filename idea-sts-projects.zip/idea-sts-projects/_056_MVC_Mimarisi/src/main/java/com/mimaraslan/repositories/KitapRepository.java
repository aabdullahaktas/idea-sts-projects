package com.mimaraslan.repositories;

public class KitapRepository {
}
