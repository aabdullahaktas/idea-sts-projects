package com.mimaraslan.v4;

public interface Kargo {

    public float agirlikDurumu(double yuk);
}
