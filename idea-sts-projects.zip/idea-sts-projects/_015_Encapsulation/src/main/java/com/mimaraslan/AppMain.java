package com.mimaraslan;

public class AppMain {

    public static void main(String[] args) {

        Dikdortgen dikdortgen = new Dikdortgen(10, 3);
        System.out.println(dikdortgen.getHesaplaAlan());
        System.out.println(dikdortgen.getHesaplaCevre());



       // dikdortgen.kisaKenar = 55;
       // System.out.println(dikdortgen.getHesaplaCevre());



    }
}
