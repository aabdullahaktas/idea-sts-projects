package com.mimaraslan;

public interface Memeli {

    void sutleBeslen();

    void dogumYap();
}
