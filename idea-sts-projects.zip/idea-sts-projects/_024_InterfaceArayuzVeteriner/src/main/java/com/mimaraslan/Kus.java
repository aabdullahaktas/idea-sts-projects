package com.mimaraslan;

public interface Kus {

    void kanatCirp();

    void yumurtla();
}
