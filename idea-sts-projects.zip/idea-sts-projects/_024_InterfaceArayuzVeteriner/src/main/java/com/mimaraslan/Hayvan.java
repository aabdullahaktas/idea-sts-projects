package com.mimaraslan;

public abstract class Hayvan {

    public abstract void yemekYe();

    public void yuz(){

    }

    public void uc(){

    }

    public void tirman(){

    }


}
