package com.mimaraslan;

public interface Balik {

    void yuzgecDurumu();

    void yumurtla();
}
