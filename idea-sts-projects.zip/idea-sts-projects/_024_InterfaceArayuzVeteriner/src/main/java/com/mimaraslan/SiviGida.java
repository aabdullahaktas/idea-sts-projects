package com.mimaraslan;

public interface SiviGida {
    void suIc();
}
