package com.mimaraslan;

public interface KatiGida {

}
