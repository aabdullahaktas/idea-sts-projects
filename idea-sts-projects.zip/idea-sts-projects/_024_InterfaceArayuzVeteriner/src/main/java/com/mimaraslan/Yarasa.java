package com.mimaraslan;

public class Yarasa extends Hayvan implements Memeli, SiviGida{

    @Override
    public void yemekYe() {

    }

    @Override
    public void sutleBeslen() {

    }

    @Override
    public void dogumYap() {

    }

    @Override
    public void uc(){

    }

    @Override
    public void tirman(){

    }

    @Override
    public void suIc() {

    }
}
