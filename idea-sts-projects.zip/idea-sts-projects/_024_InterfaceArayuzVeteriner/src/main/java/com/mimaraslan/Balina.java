package com.mimaraslan;

public class Balina extends Hayvan implements Memeli{


    @Override
    public void yemekYe() {

    }

    @Override
    public void sutleBeslen() {

    }

    @Override
    public void dogumYap() {

    }

    @Override
    public void yuz(){

    }

}
