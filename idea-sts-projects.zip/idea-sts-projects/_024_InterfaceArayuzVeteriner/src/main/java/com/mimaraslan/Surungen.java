package com.mimaraslan;

public interface Surungen {
}
