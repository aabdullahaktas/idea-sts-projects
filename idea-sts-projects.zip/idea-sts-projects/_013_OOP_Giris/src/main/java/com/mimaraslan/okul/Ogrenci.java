package com.mimaraslan.okul;

public class Ogrenci {

    int numarasi;
    String adi;
    String soyadi;


}
