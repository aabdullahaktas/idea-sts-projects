package com.mimaraslan.muhasebe;

public class B extends MusteriHesap {
}
