package com.mimaraslan.muhasebe;

public class MusteriHesap {

   private long musteriNo;

   private String email;

   private float maas;



    public long getMusteriNo() {
        return musteriNo;
    }

    public void setMusteriNo(long musteriNo) {
        this.musteriNo = musteriNo;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public float getMaas() {
        return maas;
    }

    public void setMaas(float maas) {
        this.maas = maas;
    }



}
