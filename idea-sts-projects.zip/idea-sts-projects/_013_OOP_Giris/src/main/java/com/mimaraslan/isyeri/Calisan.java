package com.mimaraslan.isyeri;

public class Calisan {
    float agariUcret = 20_000f;
    boolean sigorta = true;
    int izinHakki = 14;

}
