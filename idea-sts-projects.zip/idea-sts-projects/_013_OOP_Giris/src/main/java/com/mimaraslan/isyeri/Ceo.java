package com.mimaraslan.isyeri;

public class Ceo extends Calisan{

    float bonus = 85000f;
    boolean ozelSaglikSigortasi = true;

    int ekIzin = 60;
}
