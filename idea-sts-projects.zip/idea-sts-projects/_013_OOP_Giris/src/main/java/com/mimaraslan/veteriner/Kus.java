package com.mimaraslan.veteriner;

public class Kus extends EvcilHayvan{
    @Override
    void hayvanSesVer() {
        System.out.println("Cik cik");
    }

    @Override
    void yazdir() {
        System.out.println("Kuş sınıfı");
    }



}
