package com.mimaraslan.muhasebe;

public class A extends MusteriHesap{

}
