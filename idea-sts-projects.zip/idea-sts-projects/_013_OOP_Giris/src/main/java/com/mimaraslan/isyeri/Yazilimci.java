package com.mimaraslan.isyeri;

public class Yazilimci extends Calisan {

    float bonus = 35_000f;

    boolean ozelSaglikSigortasi = false;


}
